Structured Output Prediction using Conditional Random Fields

Project description

o Implemented a conditional random field model for Optical Character Recognition(OCR), with emphasis on inference and performance test. 
o Benchmarking done by comparing CRF with multi-class linear SVM
